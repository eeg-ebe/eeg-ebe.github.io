#!/usr/bin/perl --

#Copyright (c) 2009-2015, Jean-François Flot <http://dx.doi.org/10.1111/j.1471-8286.2007.01857.x>
#
#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is
#hereby granted, provided that the above copyright notice and this permission notice appear in all copies.
#
#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE
#INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
#ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF
#USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
#OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

use warnings;
use strict;
use Getopt::Std;
print "\n";

print "Champuru (command-line version)\n\n";

print "Reference:\nFlot, J.-F. (2007) Champuru 1.0: a computer software for unraveling mixtures of two DNA sequences of unequal lengths. Molecular Ecology Notes 7 (6): 974-977\n\n";

print "Usage: perl champuru.pl -f <forward sequence> -r <reverse sequence> -o <FASTA output> -n <sample name> -c\nThe forward and reverse sequences should be provided as text files (with the whole sequence on a single line).\nPlease use the switch -c if the reverse sequence has to be reverse-complemented (this switch should not be used if the sequence has already been reverse-complemented, for instance because it is copied from a contig editor).\nIf an output file name is specified and no problem is detected in the input data, the two reconstructed sequences will be appended to the output file in FASTA format using the specified sample name followed by 'a' and 'b'.\n\n";

our($opt_f, $opt_r, $opt_o, $opt_n, $opt_c);

getopts('f:r:o:n:c');

unless (defined($opt_f) and (defined($opt_r))) {print "Please provide the paths to the forward and reverse sequences.\n"; exit};

if (defined($opt_f)) {
open (F, $opt_f) || die "Error: Cannot open forward sequence file $opt_f.\n"};
if (defined($opt_r))  {
open (R, $opt_r) || die "Error: Cannot open reverse sequence file $opt_r.\n"};

sub max { my $max = shift; $_ > $max and $max = $_ for @_; $max };
sub min { my $min = shift; $_ < $min and $min = $_ for @_; $min };

my@bases = ('A', 'T', 'G', 'C', 'R', 'Y', 'M', 'K', 'W', 'S', 'V', 'B', 'H', 'D', 'N');
my %complement = ('A'=>'T', 'T'=>'A', 'G'=>'C', 'C'=>'G', 'R'=>'Y', 'Y'=>'R', 'M'=>'K', 'K'=>'M', 'W'=>'W', 'S'=>'S', 'V'=>'B', 'B'=>'V', 'H'=>'D', 'D'=>'H', 'N'=>'N');
my %code = ('A'=>1, 'T'=>2, 'G'=>4, 'C'=>8, 'R'=>5, 'Y'=>10, 'M'=>9, 'K'=>6, 'W'=>3, 'S'=>12, 'V'=>13, 'B'=>14, 'H'=>11, 'D'=>7, 'N'=>15);
my %rev_code = (1=>'A', 2=>'T', 4=>'G', 8=>'C', 5=>'R', 10=>'Y', 9=>'M', 3=>'W', 12=>'S', 6=>'K', 13=>'V', 14=>'B', 11=>'H', 7=>'D', 15=>'N');

sub comp { my $compatible; my $intersection;
$intersection = ($code{$_[0]} & $code{$_[1]});
if ($intersection == 0) {$compatible = 0} else {$compatible=1}
return ($compatible)}  ;

sub inter { my $intersection;
$intersection = ($code{$_[0]} & $code{$_[1]});
if ($intersection == 0) { $intersection = '_'}
      else {$intersection=$rev_code{$intersection}};
return ($intersection)};

#processing input data
my $for = <F>; chomp($for); my@forward=split('', $for);
foreach my$r(@forward){if (!grep(/$r/, @bases)) {print "Unknown base ($r) in forward sequence!"; exit}};
my $rev = <R>; chomp($rev); my@reverse=split('', $rev);
foreach my$r(@reverse){if (!grep(/$r/, @bases)) {print "Unknown base ($r) in reverse sequence!"; exit}};
print "Length of forward sequence: $#forward bases\n";
print "Lenth of reverse sequence: $#reverse bases\n";

if ($opt_c) {@reverse=reverse(@reverse); foreach my$base(@reverse){$base=$complement{$base}}};

#computing the scores of all possible alignments
my $scoremax1 = 0; my $scoremax2=0; my $scoremax3=0 ;
my $imax1=0; my $imax2=0 ; my $imax3=0;
my $i; my $j;
for ($i=(-$#forward); $i<=($#reverse) ;$i++) {
				my $score = 0;
				if ($i<0) {for ($j=0; $j<=min(($#forward+$i),$#reverse);$j++) {$score=($score+comp($forward[$j-$i],$reverse[$j]))}; $score=$score-(($#forward+$i)+1)/4}
				elsif ($i>0) {for ($j=0; $j<=min($#forward,($#reverse-$i));$j++){$score=($score+comp($forward[$j],$reverse[$j+$i]))}; $score=$score-(($#reverse-$i)+1)/4}
				elsif ($i==0) {for ($j=0; $j<=min($#forward,$#reverse);$j++){$score=($score+comp($forward[$j],$reverse[$j]))}; $score=$score-(min($#forward,$#reverse)+1)/4};

        if ($score > $scoremax1) {$imax3=$imax2; $imax2=$imax1; $imax1=$i; $scoremax3=$scoremax2; $scoremax2=$scoremax1; $scoremax1=$score}
				elsif ($score > $scoremax2){$imax3=$imax2; $imax2=$i; $scoremax3=$scoremax2; $scoremax2=$score}
				elsif ($score > $scoremax3){$imax3=$i; $scoremax3=$score}} ;

print "Best compatibility score: $scoremax1 (offset: $imax1)\n";
print "Second best compatibility score: $scoremax2 (offset: $imax2)\n";
print "Third best compatibility score: $scoremax3 (offset: $imax3)\n\n";

#combining forward and reverse information into strict consensus sequences
my @seq1;
my @seq2;

for ($j=-min($imax1,0); $j<=min($#forward,$#reverse-$imax1);$j++) {
  $seq1[$j+min($imax1,0)]=inter($forward[$j],$reverse[$j+min($imax1,0)+max($imax1,0)])}
  
for ($j=-min($imax2,0); $j<=min($#forward,$#reverse-$imax2);$j++) {
  $seq2[$j+min($imax2,0)]=inter($forward[$j],$reverse[$j+min($imax2,0)+max($imax2,0)])}

my $incomp=0;
foreach my$r(@seq1){if ($r eq '_') {$incomp=$incomp+1}};
foreach my$r(@seq2){if ($r eq '_') {$incomp=$incomp+1}};
if ($incomp>0) {print "First reconstructed sequence: "; foreach my$r(@seq1){print $r}; print "\n";
                print "Second reconstructed sequence: "; foreach my$r(@seq2){print $r}; print "\n"}
if ($incomp==1) {print "There is 1 incompatible position (indicated with an underscore), please check the input sequences.\n" ; exit};
if ($incomp>1) {print "There are $incomp incompatible positions (indicated with underscores), please check the input sequences.\n" ; exit};

#cleaning up ambiguities by sequence comparison
my @seq1rev=reverse(@seq1); my @seq2rev=reverse(@seq2);
my @reverserev=reverse(@reverse);
splice(@seq1rev,0,max(min($#forward-$#reverse+$imax1,0)-min($#forward-$#reverse+$imax2,0),0));
splice(@seq2rev,0,max(min($#forward-$#reverse+$imax2,0)-min($#forward-$#reverse+$imax1,0),0));
my $cutreverserev=-min($#forward-$#reverse+min($imax1,$imax2),0);
splice(@reverserev,0,$cutreverserev);
@seq1=reverse(@seq1rev); @seq2=reverse(@seq2rev);@reverse=reverse(@reverserev);
splice(@seq1,0,max(min($imax1,0)-min($imax2,0),0));
splice(@seq2,0,max(min($imax2,0)-min($imax1,0),0));
my $cutforward=-min(min($imax1,$imax2),0);
splice(@forward,0,$cutforward);

for ($i=0;$i<3;$i++){
for ($j=0;$j<=min($#seq1,$#seq2);$j++) {
      if ($seq1[$j] ne $seq2[$j]) {
    if (comp($seq1[$j],$seq2[$j])==1) {
      if  ($code{$seq1[$j]} > $code{$seq2[$j]}) {
            $seq1[$j]=$rev_code{$code{$seq1[$j]}-$code{$seq2[$j]}}}
      else {$seq2[$j]=$rev_code{$code{$seq2[$j]}-$code{$seq1[$j]}}}}} ;
      if ($seq1[$#seq1-$j] ne $seq2[$#seq2-$j]) {
		if (comp($seq1[$#seq1-$j],$seq2[$#seq2-$j])==1) {
      if  ($code{$seq1[$#seq1-$j]} > $code{$seq2[$#seq2-$j]}) {
            $seq1[$#seq1-$j]=$rev_code{$code{$seq1[$#seq1-$j]}-$code{$seq2[$#seq2-$j]}}}
      else {$seq2[$#seq2-$j]=$rev_code{$code{$seq2[$#seq2-$j]}-$code{$seq1[$#seq1-$j]}}}}}
					}};
print "First reconstructed sequence: ";
foreach my$r(@seq1){print "$r"}; print "\n";
print "Second reconstructed sequence: ";
foreach my$r(@seq2){print "$r"}; print "\n";

#simulating direct sequencing
my @tocheck=('s');
for ($j=0; $j<=min($#seq1,$#seq2);$j++) {
  if ($code{$forward[$j]}!=($code{$seq1[$j]}|$code{$seq2[$j]})) {push(@tocheck,$j+$cutforward+1)}};
my $ftocheck=$#tocheck;
if ($#tocheck > 0) {print "Check position";
if ($#tocheck==1) {print " $tocheck[1] "} else {foreach my$r(@tocheck){print "$r "}};
  print "on the forward chromatogram.\n"};

@tocheck=('s');
for ($j=0; $j<=min($#seq1,$#seq2);$j++) {
  if ($code{$reverse[$#reverse-$j]}!=($code{$seq1[$#seq1-$j]}|$code{$seq2[$#seq2-$j]})) {
    if (!$opt_c) {@tocheck=(@tocheck,1+$#reverse-$j)} else {push(@tocheck,$j+$cutreverserev+1)}  }};
my $rtocheck=$#tocheck;
if ($#tocheck > 0) {print "Check position";
if ($#tocheck==1) {print " $tocheck[1] "} else {
  if (!$opt_c)  {@tocheck=reverse(@tocheck); unshift(@tocheck,pop(@tocheck))};
  foreach my$r(@tocheck){print "$r "}};
print "on the reverse chromatogram.\n"};
if ($ftocheck+$rtocheck<1) {print "The two sequences that were mixed in the forward and reverse chromatograms have been successfully deconvoluted.\n"};

#writing FASTA output if all problems have been solved
if ($#tocheck == 0) {if (defined($opt_o)) {
if (!open (F, ">> $opt_o")) {die "Writing error: $!\n"};
if (!defined($opt_n)){$opt_n=""};
print F ">",$opt_n,"a\n";
foreach my$r(@seq1){print F "$r"}; print F "\n";
print F ">",$opt_n,"b\n";
foreach my$r(@seq2){print F "$r"}; print F "\n";
print "They have been appended to the file ",$opt_o," in FASTA format under the names '",$opt_n,"a' and '",$opt_n,"b'.\n";
close F; 
 }};


